import React,{Component} from 'react'

class Counter extends Component{
    constructor(props){
        super(props);
    }
    componentWillMount(){
        console.log('component will mount called')
      }
      componentDidMount(){
        console.log('component did mount called')
      }
    render(){
        console.log('component rendered')
        return(
            <div className='container'>
                <div className='row'>
                    <div className='col-md-12 text-center'>
                        <h3 className='display-3 text-warning'>Counter</h3>
                    </div>
                </div>
                <div className='row'>
                    <div className='col-md-12'>
                        <h1 className='display-1'>
                            {this.state.view?"Welcome to React Lifecycle" :"Need More Counts"}</h1>
                    </div>
                </div>
               
            </div>
        )
    }

componentWillUnmount(){
    console.log('component unmounted successfully')
}
}
export default Counter;